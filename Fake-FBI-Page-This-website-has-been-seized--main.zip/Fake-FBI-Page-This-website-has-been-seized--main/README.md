# Fake FBI Page (This website has been Seized)

Dont ask 

![](https://cdn.discordapp.com/attachments/800195998235623425/881695835769958400/unknown.png)
